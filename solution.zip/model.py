"""
ClearSky Challenge - Baseline Submission
==========================================
This is the reference solution provided to participants as a starting point.

It implements a Random Forest Regressor with basic feature engineering.
Participants are encouraged to beat this baseline!

Expected interface:
    model = Model()
    model.fit(X_train, y_train)   # X: pd.DataFrame, y: np.ndarray
    predictions = model.predict(X_test)  # returns np.ndarray
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


class Model:
    """
    Baseline model: Random Forest Regressor with median imputation.

    This model:
    - Fills missing values with the median of each feature
    - Applies standard scaling
    - Fits a Random Forest with 100 trees

    Participants can replace this class with any model they choose.
    The only requirements are:
      - __init__(self)  : no required arguments
      - fit(X, y)       : trains the model
      - predict(X)      : returns predictions as a numpy array
    """

    def __init__(self):
        self.pipeline = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("regressor", RandomForestRegressor(
                n_estimators=100,
                max_depth=15,
                min_samples_leaf=5,
                n_jobs=-1,
                random_state=42,
            )),
        ])

    def fit(self, X: pd.DataFrame, y: np.ndarray):
        """
        Train the model.

        Parameters
        ----------
        X : pd.DataFrame
            Feature matrix (n_samples, n_features)
        y : np.ndarray
            Target PM2.5 concentrations in µg/m³ (n_samples,)
        """
        # Drop rows where target is NaN
        mask = ~np.isnan(y.astype(float))
        X_clean = X[mask]
        y_clean = y[mask]

        self.pipeline.fit(X_clean, y_clean)
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        Predict PM2.5 concentrations.

        Parameters
        ----------
        X : pd.DataFrame
            Feature matrix (n_samples, n_features)

        Returns
        -------
        np.ndarray
            Predicted PM2.5 concentrations in µg/m³ (n_samples,)
        """
        predictions = self.pipeline.predict(X)
        # PM2.5 cannot be negative
        return np.clip(predictions, 0, None)
